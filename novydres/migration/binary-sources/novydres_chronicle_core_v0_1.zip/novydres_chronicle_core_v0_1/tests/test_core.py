import json
import hashlib
import tempfile
import unittest
from pathlib import Path
from novydres_core import Chronicle, GuardrailError, create_player_key, sign_declaration, score_v5


class FixedRNG:
    def __init__(self, seq): self.values=iter(seq)
    def randint(self, low, high): return next(self.values)


class ChronicleTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.root=Path(self.temp.name)
        self.priv=self.root/'player.key'
        self.pub=self.root/'player.pub'
        create_player_key(self.priv,self.pub)
        self.path=self.root/'campaign.sqlite3'
        self.e=Chronicle(self.path)
        self.e.register_player(self.pub.read_bytes().hex())

    def tearDown(self):
        self.e.close()
        self.temp.cleanup()

    def declared(self, kind, text):
        token=sign_declaration(self.priv,kind,text)
        return self.e.accept_declaration(token)

    def attempt(self,text='Tento convencer o segurança.'):
        d=self.declared('attempt',text)
        return self.e.append_event(kind='player_attempt', actor='pc',description=text,declaration_id=d)

    def import_character(self):
        delta=[
                {'key':'pc.hunger','before':None,'after':2,'reason':'import:approved'},
                {'key':'pc.willpower.current','before':None,'after':4,'reason':'import:approved'},
                {'key':'pc.location','before':None,'after':'portão','reason':'import:approved'}]
        digest=hashlib.sha256(json.dumps(delta,sort_keys=True,separators=(',', ':'),ensure_ascii=False).encode()).hexdigest()
        d=self.declared('choice','IMPORT_CHARACTER approved sheet sha256: '+digest)
        return self.e.append_event(kind='character_import',actor='system', description='Aprovação da ficha teste',
            declaration_id=d, state_delta=delta)

    def test_T01_attempt_is_not_walked_through_door(self):
        event=self.attempt()
        with self.assertRaisesRegex(GuardrailError,'literal declaration'):
            self.e.append_event(kind='player_attempt',actor='pc',description='Tento convencer e entro pela porta.',
                                declaration_id=self.declared('attempt','Tento convencer o segurança.'))
        with self.assertRaisesRegex(GuardrailError,'position'):
            self.e.append_event(kind='world_event',actor='world',description='Entrou',causal_refs=[event],
                 state_delta=[{'key':'pc.location','before':None,'after':'dentro','reason':'extrapolação'}])
        self.assertEqual(len(self.e.events()),1)

    def test_T02_hypothetical_question_not_attack(self):
        question=self.declared('question','E se eu matasse o segurança?')
        with self.assertRaises(GuardrailError):
            self.e.append_event(kind='player_action',actor='pc',description='Eu mato o segurança.',declaration_id=question)
        self.assertEqual(self.e.events(),[])

    def test_T03_plan_does_not_kill(self):
        plan=self.e.append_event(kind='gm_plan',actor='npc.1',description='Planeja matar outro NPC')
        with self.assertRaisesRegex(GuardrailError,'not an accomplished fact'):
            self.e.append_event(kind='gm_plan',actor='npc.1',description='Mata NPC',state_delta=[
                {'key':'npc.2.alive','before':None,'after':False,'reason':'intenção'}])
        with self.assertRaises(GuardrailError):
            self.e.append_event(kind='world_event',actor='world',description='NPC morreu')
        self.assertEqual(self.e.events()[0]['kind'],'gm_plan')
        self.assertEqual(plan,self.e.events()[0]['id'])

    def test_T04_optional_willpower_requires_player_choice(self):
        self.import_character()
        with self.assertRaisesRegex(GuardrailError,'signed player declaration'):
            self.e.append_event(kind='world_event',actor='npc.1',description='Gasto de WP',causal_refs=[self.e.events()[-1]['id']],
                state_delta=[{'key':'pc.willpower.current','before':4,'after':3,'reason':'optional:reroll'}],source_rule='v5')
        self.assertEqual(self.e.state()['pc.willpower.current'],4)

    def test_T05_verified_dice_and_raw_output(self):
        self.import_character()
        anchor=self.attempt()
        with self.assertRaisesRegex(GuardrailError,'anchored'):
            self.e.prepare_roll(pool=5,hunger=2,difficulty=3,label='Teste',actor='pc',rule_source='V5',causal_refs=[])
        prep=self.e.prepare_roll(pool=5,hunger=2,difficulty=3,label='Persuasão',actor='pc',rule_source='V5',causal_refs=[anchor])
        result=self.e.execute_roll(prep,_rng=FixedRNG([10,6,4,1,10]))
        self.assertEqual(result['raw']['normal'],[10,6,4])
        self.assertEqual(result['raw']['hunger'],[1,10])
        self.assertEqual(result['outcome']['successes'],5)
        self.assertTrue(result['outcome']['messy_critical'])
        replay=self.e.execute_roll(prep,_rng=FixedRNG([1,1,1,1,1]))
        self.assertEqual(result['roll_id'],replay['roll_id'])
        self.assertTrue(replay['idempotent'])
        self.assertTrue(self.e.verify_integrity()['ok'])

    def test_T06_rouse_causes_hunger_and_state_log(self):
        self.import_character()
        anchor=self.attempt('Eu uso uma habilidade que exige um teste de Despertar.')
        p=self.e.prepare_roll(pool=1,hunger=0,difficulty=1,label='Despertar do Sangue',actor='pc',
                              rule_source='V5:Rouse',causal_refs=[anchor],test_type='rouse')
        o=self.e.execute_roll(p,_rng=FixedRNG([3]))
        self.assertEqual(self.e.state()['pc.hunger'],3)
        self.assertEqual(o['outcome']['hunger_before'],2)
        self.assertFalse(o['outcome']['rouse_success'])
        self.assertEqual(self.e.events()[-1]['data']['state_delta'][0]['reason'],'involuntary:rouse_failed')
        self.assertTrue(self.e.verify_integrity()['ok'])

    def test_T07_npc_cannot_use_unrecorded_knowledge(self):
        a=self.attempt()
        with self.assertRaisesRegex(GuardrailError,'lacks registered knowledge'):
            self.e.append_event(kind='npc_action',actor='npc.security',description='Usa segredo',causal_refs=[a],knowledge_used=['SECRET-001'])
        self.e.append_event(kind='world_event',actor='world',description='Segredo revelado em público',causal_refs=[a],
                            knowledge_granted=[{'actor':'npc.security','fact':'SECRET-001'}])
        self.e.append_event(kind='npc_action',actor='npc.security',description='Agora sabe',knowledge_used=['SECRET-001'])
        self.assertTrue(self.e.verify_integrity()['ok'])

    def test_T08_npc_claim_not_world_truth(self):
        eid=self.e.append_event(kind='npc_claim',actor='npc.liar',description='Afirma falsamente que o PC entrou')
        self.assertEqual(self.e.events()[0]['kind'],'npc_claim')
        with self.assertRaises(GuardrailError):
            self.e.append_event(kind='npc_claim',actor='npc.liar',description='Alega',
                                state_delta=[{'key':'pc.location','before':None,'after':'dentro','reason':'alegação'}])
        self.assertEqual(self.e.state(),{})

    def test_T09_restart_rebuilds_checkpoint(self):
        self.import_character()
        first=self.e.checkpoint()
        self.e.close()
        self.e=Chronicle(self.path)
        second=self.e.checkpoint()
        self.assertEqual(first,second)
        self.assertTrue(second['character_present'])
        self.assertTrue(second['integrity']['ok'])

    def test_T10_rollback_no_partial_sync(self):
        e=self.attempt()
        count=self.e.verify_integrity()['events']
        with self.assertRaises(GuardrailError):
            self.e.append_event(kind='world_event',actor='world',description='Bad delta',causal_refs=[e],state_delta=[
                {'key':'world.temperature','before':None,'after':-3,'reason':'termômetro'},
                {'key':'pc.location','before':None,'after':'entrou','reason':'suposição'}])
        self.assertNotIn('world.temperature',self.e.state())
        self.assertEqual(count,self.e.verify_integrity()['events'])

    def test_T11_canon_is_readonly(self):
        with self.assertRaisesRegex(GuardrailError,'read-only'):
            self.e.append_event(kind='npc_action',actor='npc.any',description='Change canon',canon_change=True)
        with self.assertRaisesRegex(GuardrailError,'canon'):
            self.e.append_event(kind='npc_action',actor='npc.any',description='Change canon',state_delta=[
                {'key':'canon.Novydres.year','before':None,'after':2011,'reason':'inventado'}])

    def test_T12_correction_is_append_only(self):
        old=self.e.append_event(kind='npc_claim',actor='npc.liar',description='Alegação incorreta')
        payload={'target':old,'description':'Correção formal','delta':[]}
        digest=hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(',', ':'),ensure_ascii=False).encode()).hexdigest()
        choice=self.declared('choice',f'AUTORIZO CORRECTION {old} {digest}')
        fix=self.e.append_event(kind='correction',actor='system',description='Correção formal',
                                declaration_id=choice,correction_of=old)
        self.assertEqual([x['id'] for x in self.e.events()],[old,fix])
        self.assertEqual(self.e.events()[1]['data']['correction_of'],old)

    def test_twenty_seven_roll_math_examples(self):
        self.assertEqual(score_v5([10,10,5],[4],3)['successes'],4)
        self.assertTrue(score_v5([1],[1],1)['bestial_failure'])
        self.assertFalse(score_v5([6],[1],1)['bestial_failure'])
        self.assertTrue(score_v5([10],[10],2)['messy_critical'])

    def test_signature_tampering_is_rejected(self):
        token=sign_declaration(self.priv,'action','Eu entro')
        token['payload']['text']='Eu mato o Príncipe'
        with self.assertRaises(GuardrailError): self.e.accept_declaration(token)

    def test_integrity_catches_manual_tampering(self):
        self.attempt()
        self.e.db.execute("UPDATE events SET data='{}' WHERE seq=1")
        v=self.e.verify_integrity()
        self.assertFalse(v['ok'])
        self.assertTrue(any('modified event' in x for x in v['errors']))

    def test_willpower_reroll_requires_signed_explicit_choice(self):
        self.import_character()
        a=self.attempt('Tento barganhar com o segurança.')
        p=self.e.prepare_roll(pool=4,hunger=2,difficulty=2,label='Persuasão',actor='pc',rule_source='V5',causal_refs=[a])
        first=self.e.execute_roll(p,_rng=FixedRNG([2,5,6,7]))
        with self.assertRaises(GuardrailError):
            self.e.reroll_willpower(first['roll_id'],[0],self.declared('choice','Quero refazer'))
        consent=self.declared('choice','REROLL autorizo ' + first['roll_id'] + ' indices=0,1 usando Força de Vontade')
        result=self.e.reroll_willpower(first['roll_id'],[0,1],consent,_rng=FixedRNG([10,10]))
        self.assertEqual(result['outcome']['successes'],6)
        self.assertEqual(self.e.state()['pc.willpower.current'],3)
        self.assertTrue(self.e.verify_integrity()['ok'])
        with self.assertRaises(GuardrailError): self.e.reroll_willpower(first['roll_id'],[0],consent)

    def test_reusing_same_declaration_is_rejected(self):
        text='Eu digo boa noite.'
        d=self.declared('speech',text)
        self.e.append_event(kind='player_speech',actor='pc',description=text,declaration_id=d)
        with self.assertRaises(GuardrailError):
            self.e.append_event(kind='player_speech',actor='pc',description=text,declaration_id=d)

    def test_private_npc_note_does_not_leak_in_public_events(self):
        self.e.append_event(kind='gm_plan',actor='npc.private',description='Segredo',visibility='GM_HIDDEN')
        self.assertEqual(self.e.events(),[])
        self.assertEqual(len(self.e.events(include_hidden=True)),1)

if __name__=='__main__': unittest.main()
