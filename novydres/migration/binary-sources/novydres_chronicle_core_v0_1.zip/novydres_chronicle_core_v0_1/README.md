# NOVYDRES — Chronicle Core v0.1.0

**Status:** núcleo executável local, testado em 28/10/2026. **Não** é cânone do cenário, nem projeto VTT completo, nem integração automática do ChatGPT com o Google Drive.

## O que foi implementado

- SQLite local, `BEGIN IMMEDIATE` + commit/rollback para salvar **evento, rolagem e delta da ficha atomicamente**.
- Registro de eventos com IDs, causalidade, proveniência, controles para `PLAYER_*` / `NPC_ACTION` / `WORLD_EVENT` / `NPC_CLAIM` / `GM_PLAN` / `CORRECTION`.
- Ações voluntárias do PC exigem **declaração literal assinada com Ed25519**, cuja chave **privada permanece com o jogador** (não compartilhar com o Narrador e não publicar no Drive).
- Ficha inicial somente via importação explicitamente aprovada com SHA-256 do conjunto exato de deltas; estado atual derivado do registro persistido.
- Motor V5: paradas d10 com dados de Fome separados, sucessos (6+), pares de 10, crítico bagunçado e falha bestial; teste de Despertar com variação de Fome; rerrolagem de até três dados não-Fome com Força de Vontade após escolha assinada.
- Pré-registro de parâmetros da rolagem; execução única/idempotente; resultados brutos + hashes; testes T01–T12 e outros, suite `unittest`.
- Checkpoint, recuperação entre processos, auditoria de cadeia SHA-256, estado derivado, exportação player-safe e backup físico SQLite.
- Não há personagem, evento de história ou rolagem de jogo real neste pacote.

## Requisitos

Python 3.11+ e `cryptography` (Ed25519). Em Ubuntu:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python -m unittest discover -s tests -v
```

## Iniciar (na máquina do jogador)

```bash
# O motor aceita um banco local novo; estado inicia PREPARATION, sem personagem.
python cli.py --db data/cronica.sqlite3 checkpoint

# Execute estes comandos APENAS em um dispositivo do jogador não acessível à IA:
python cli.py keygen --private ~/novydres-player.key --public ~/novydres-player.pub

# Registrar SOMENTE a chave pública na base do motor
python cli.py --db data/cronica.sqlite3 register-player --public ~/novydres-player.pub

# O jogador assina uma tentativa específica sem compartilhar a chave privada:
python cli.py sign --private ~/novydres-player.key --kind attempt \
  --text 'Tento convencer o segurança a abrir a porta.' --output /tmp/player.token.json

# Aceitar a declaração (o Narrador pode usar apenas o TOKEN assinado):
python cli.py --db data/cronica.sqlite3 accept /tmp/player.token.json
```

Depois de obter o `declaration_id` da aceitação, crie um arquivo `candidate.json` com:

```json
{
  "kind": "player_attempt",
  "actor": "pc",
  "description": "Tento convencer o segurança a abrir a porta.",
  "declaration_id": "DECL-COLE_O_ID_EXATO"
}
```

E confirme:

```bash
python cli.py --db data/cronica.sqlite3 event candidate.json
```

O motor **rejeita** tentativas de converter essa tentativa em decisão de entrar: é necessário outro token, assinado pelo jogador, contendo a ação de entrar.

## Importar ficha aprovada

Preencha um candidato `character_import` com deltas da ficha (ex.: `pc.hunger`, `pc.willpower.current`, atributos, perícias, etc.), todos com `before: null` e `after` correto. Não invente valores. Exija validação conforme os módulos canônicos A–K antes do envio.

1. `python cli.py --db data/cronica.sqlite3 fingerprint ficha_candidate.json` retorna SHA-256 do conjunto **exato** de deltas.
2. O jogador aprova com uma declaração assinada `--kind choice --text 'IMPORT_CHARACTER sha256:<hash>'`.
3. Aceite o token e associe o `declaration_id` à ficha candidata.
4. Execute `python cli.py --db data/cronica.sqlite3 event ficha_candidate.json`.

O contrato exige valores antes/depois exatos, hash na aprovação, e impede importar a ficha duas vezes. Validação semântica completa dos custos/chassi V5 de Novydres **não** está implementada: depende dos arquivos A–K atuais.

## Rolagem com ficha importada

Após declarar e confirmar uma ação/tentativa, crie `roll.json`:

```json
{
  "pool": 7,
  "hunger": 2,
  "difficulty": 3,
  "label": "Manipulação + Persuasão",
  "actor": "pc",
  "rule_source": "V5_baseline_validado",
  "causal_refs": ["EVT-COLE_ID_DA_TENTATIVA"]
}
```

```bash
python cli.py --db data/cronica.sqlite3 prepare-roll roll.json
python cli.py --db data/cronica.sqlite3 roll PREP-COLE_ID
python cli.py --db data/cronica.sqlite3 audit
python cli.py --db data/cronica.sqlite3 checkpoint
```

**Importante:** `hunger` deve coincidir com a Fome atual da ficha. Teste de Despertar usa `test_type: "rouse"`, `pool:1`, `hunger:0`, `difficulty:1`, e é salvo atomicamente com a mudança de Fome. Para rerrolar, use escolha assinada `REROLL <ROLL-ID> indices=0,1` e `python cli.py ... reroll <ROLL-ID> --indices 0,1 --choice <DECL-ID>`; gasto de 1 WP entra na mesma transação.

## Auditoria e backup

```bash
python cli.py --db data/cronica.sqlite3 audit
python cli.py --db data/cronica.sqlite3 export --out backup/player_safe_001.json
python cli.py --db data/cronica.sqlite3 backup --out backup/cronica_001.sqlite3
```

Não envie uma `backup` completa aos jogadores quando contiver segredos do Narrador. O export player-safe **não** contém notas `GM_HIDDEN` do ledger; a ficha/estado também pode conter spoilers se assim for alimentada, portanto segregue campos sensíveis antes de exportar para público.

## Segurança e limites reais

1. **Assinatura só funciona como fronteira de autoria quando a chave privada do jogador está fora do alcance do Narrador/IA**. Se a IA puder operar o dispositivo que guarda a chave, poderá assinar mensagens: essa garantia cai.
2. A assinatura assegura origem e conteúdo literal, **não** compreensão semântica da língua natural. O modelo ainda pode propor fatos falsos em texto; o sistema restringe o que é persistido e expõe evidências.
3. Cadeia SHA-256 detecta adulterações acidentais/simples, mas um administrador com acesso total ao SQLite pode reescrever todo o banco e recalcular a cadeia. Para resistência a adulteração, copie periodicamente o hash final para local externo controlado pelo jogador.
4. O gerador usa `secrets.SystemRandom` quando chamado pela CLI. A função interna `_rng` serve só aos testes. Não fornece prova criptográfica pública de imparcialidade de sorteios controlados pelo mesmo executor.
5. Não implementa **todas** as regras de V5, criação de PC Novydres, combate, poderes/rituais, humanidade, predador, validade de todos os atributos, imutabilidade de software, verificação automática do lore ou integração com o VTT do usuário.
6. `WORLD_EVENT` precisa de causa registrada, mas código sozinho **não consegue garantir** semântica causal completa, nem detectar conhecimento de NPC omitido pelo Narrador. Revisão humana/IA sob o contrato continua necessária.
7. SQLite é a fonte local da verdade para esta implementação. Os documentos no Google Drive são governança/código/estado de planejamento, **não** um espelho automaticamente sincronizado. É preciso um adaptador autenticado (ou export/upload verificado) para manter logs e fichas no Drive a cada jogada.
8. O arquivo `data/cronica.sqlite3` e a chave privada **não** estão incluídos no pacote. Use backups e não compartilhe credenciais.

## Status contra EVENT_PROTOCOL_V1

- Implementado/testado localmente: T01–T12; transações SQLite; assinatura; motor básico; recuperação; hash e check.
- Pendente: fonte canônica atual `.AGENT/.CONTEXTG` de Novydres e arquivos A–K; ficha real; autorização semântica; backend isolado/serviço; adaptador de Drive online; proteção criptográfica externa de histórico; validação de sistema completo.

## Retomada

Abra a pasta no Google Drive: `NOVYDRES — Continuidade da Crônica` → `00_GOVERNANCA_DA_CRONICA`. Respeite o `.AGENT.md` e o `.CONTEXTG.md` operacionais antes de começar. Este código é V0.1.0 como **implementação técnica**, não reabre decisões do cenário nem altera os guardrails V1.
