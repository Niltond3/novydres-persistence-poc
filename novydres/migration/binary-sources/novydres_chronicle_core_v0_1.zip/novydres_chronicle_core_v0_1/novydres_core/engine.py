"""Local, transactional chronicle core (SQLite). No network; no LLM-derived authority.

Only source-verified and cryptographically signed player declarations authorize
voluntary PC actions. The key MUST stay outside the Narrator's environment.
"""
from __future__ import annotations
import hashlib
import json
import os
import secrets
import sqlite3
import uuid
from datetime import datetime, timezone
from contextlib import contextmanager
from pathlib import Path
from typing import Any

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

VERSION = "0.1.0"
GENESIS = "0" * 64
DECLARATION_KINDS = {"action", "attempt", "speech", "choice", "question"}
PLAYER_KINDS = {"player_action": "action", "player_attempt": "attempt", "player_speech": "speech", "player_choice": "choice"}
NON_FACT_KINDS = {"gm_plan", "npc_claim"}
EVENT_KINDS = set(PLAYER_KINDS) | NON_FACT_KINDS | {
    "npc_action", "world_event", "mechanical_result", "correction", "character_import"
}
FORBIDDEN_WORLD_FIELDS = {"pc.location", "pc.action", "pc.speech", "pc.choice", "pc.intent", "pc.xp_spent"}
OPTIONAL_FIELDS = {"pc.willpower.current", "pc.xp.available", "pc.hunger"}

class GuardrailError(ValueError):
    """An attempt to violate the campaign contract. Nothing was committed."""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="microseconds")


def _json(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _ident(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4().hex}"


def create_player_key(private_file: str | Path, public_file: str | Path) -> None:
    """Run on player-controlled device, NEVER in agent-owned workspace."""
    private_file, public_file = Path(private_file), Path(public_file)
    if private_file.exists() or public_file.exists():
        raise GuardrailError("Key exists: refusing overwrite")
    key = Ed25519PrivateKey.generate()
    secret = key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption())
    fd = os.open(private_file, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "wb") as f:
        f.write(secret)
    public_file.write_bytes(key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw))


def sign_declaration(private_file: str | Path, kind: str, text: str) -> dict[str, Any]:
    if kind not in DECLARATION_KINDS or not text.strip():
        raise GuardrailError("Invalid declaration kind or empty text")
    key = serialization.load_pem_private_key(Path(private_file).read_bytes(), password=None)
    if not isinstance(key, Ed25519PrivateKey):
        raise GuardrailError("Expected Ed25519 key")
    payload = {"id": _ident("DECL"), "kind": kind, "text": text, "timestamp": _now(), "speaker": "player"}
    return {"payload": payload, "signature": key.sign(_json(payload).encode()).hex()}


def score_v5(normal: list[int], hunger: list[int], difficulty: int) -> dict[str, Any]:
    """Basic V5 dice pools; rule variants require independent validation."""
    if not isinstance(difficulty, int) or not 0 <= difficulty <= 10:
        raise GuardrailError("difficulty out of range")
    if not normal and not hunger:
        raise GuardrailError("empty dice pool")
    if len(hunger) > 5 or any(type(d) is not int or d < 1 or d > 10 for d in normal + hunger):
        raise GuardrailError("invalid d10 faces/hunger count")
    all_dice = normal + hunger
    tens = sum(d == 10 for d in all_dice)
    pairs = tens // 2
    successes = sum(d >= 6 for d in all_dice) + 2 * pairs
    passed = successes >= difficulty
    messy = pairs > 0 and 10 in hunger
    bestial = (not passed) and (1 in hunger)
    return {"successes": successes, "critical_pairs": pairs, "critical": pairs > 0,
            "messy_critical": messy, "bestial_failure": bestial, "passed": passed,
            "margin": successes - difficulty}


class Chronicle:
    def __init__(self, db_path: str | Path):
        self.path = str(db_path)
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(self.path, isolation_level=None, timeout=10)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA foreign_keys=ON")
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA synchronous=FULL")
        self.db.executescript("""
            CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS declarations(
              id TEXT PRIMARY KEY, kind TEXT NOT NULL, payload TEXT NOT NULL,
              signature TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS events(
              seq INTEGER PRIMARY KEY AUTOINCREMENT, id TEXT UNIQUE NOT NULL,
              kind TEXT NOT NULL, actor TEXT NOT NULL, data TEXT NOT NULL,
              timestamp TEXT NOT NULL, prev_hash TEXT NOT NULL, hash TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS state(key TEXT PRIMARY KEY, value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS knowledge(
              actor TEXT NOT NULL, fact TEXT NOT NULL, source_event TEXT NOT NULL,
              PRIMARY KEY(actor,fact));
            CREATE TABLE IF NOT EXISTS roll_preps(
              id TEXT PRIMARY KEY, spec TEXT NOT NULL, status TEXT NOT NULL,
              event_id TEXT);
            CREATE TABLE IF NOT EXISTS rolls(
              id TEXT PRIMARY KEY, event_id TEXT UNIQUE NOT NULL, prep_id TEXT UNIQUE NOT NULL,
              raw TEXT NOT NULL, outcome TEXT NOT NULL,
              FOREIGN KEY(event_id) REFERENCES events(id));
        """)
        if self.db.execute("SELECT 1 FROM meta WHERE key='phase'").fetchone() is None:
            self.db.execute("INSERT INTO meta(key,value) VALUES('phase','PREPARATION')")
            self.db.execute("INSERT INTO meta(key,value) VALUES('schema_version',?)", (VERSION,))

    def close(self):
        self.db.close()

    @contextmanager
    def _transaction(self):
        self.db.execute("BEGIN IMMEDIATE")
        try:
            yield
            self.db.execute("COMMIT")
        except BaseException:
            self.db.execute("ROLLBACK")
            raise

    def register_player(self, pubkey_hex: str) -> None:
        try:
            Ed25519PublicKey.from_public_bytes(bytes.fromhex(pubkey_hex))
        except (ValueError, TypeError) as err:
            raise GuardrailError("invalid public key") from err
        with self._transaction():
            row = self.db.execute("SELECT value FROM meta WHERE key='player_pubkey'").fetchone()
            if row is not None:
                if row[0] != pubkey_hex:
                    raise GuardrailError("player key already registered; explicit key rotation is required")
                return
            self.db.execute("INSERT INTO meta VALUES('player_pubkey',?)", (pubkey_hex,))

    def _verify_token(self, token: dict[str, Any]) -> dict[str, Any]:
        pk = self.db.execute("SELECT value FROM meta WHERE key='player_pubkey'").fetchone()
        if not pk:
            raise GuardrailError("player public key not registered")
        try:
            payload, sig = token["payload"], bytes.fromhex(token["signature"])
            Ed25519PublicKey.from_public_bytes(bytes.fromhex(pk[0])).verify(sig, _json(payload).encode())
        except (ValueError, KeyError, TypeError) as err:
            raise GuardrailError("unsigned or invalid player declaration") from err
        except Exception as err:
            raise GuardrailError("player signature invalid") from err
        if (set(payload) != {"id", "kind", "text", "timestamp", "speaker"} or
            payload["speaker"] != "player" or payload["kind"] not in DECLARATION_KINDS or
            not isinstance(payload["text"], str) or not payload["text"].strip() or
            not str(payload["id"]).startswith("DECL-")):
            raise GuardrailError("invalid signed payload")
        return payload

    def accept_declaration(self, token: dict[str, Any]) -> str:
        payload = self._verify_token(token)
        with self._transaction():
            old = self.db.execute("SELECT payload,signature FROM declarations WHERE id=?", (payload["id"],)).fetchone()
            if old:
                if (old[0], old[1]) != (_json(payload), token["signature"]):
                    raise GuardrailError("declaration ID collision")
                return payload["id"]
            self.db.execute("INSERT INTO declarations VALUES(?,?,?,?)", (payload["id"], payload["kind"], _json(payload), token["signature"]))
        return payload["id"]

    def _get_declaration(self, id: str | None, expected: str) -> dict:
        if not id:
            raise GuardrailError("signed player declaration required")
        row = self.db.execute("SELECT payload,signature FROM declarations WHERE id=?", (id,)).fetchone()
        if not row:
            raise GuardrailError("unknown player declaration")
        payload = self._verify_token({"payload": json.loads(row[0]), "signature": row[1]})
        if payload["kind"] != expected:
            raise GuardrailError("player declaration has wrong category")
        return payload

    def _has_event(self, id: str) -> bool:
        return bool(self.db.execute("SELECT 1 FROM events WHERE id=?", (id,)).fetchone())

    def state(self) -> dict[str, Any]:
        return {r["key"]: json.loads(r["value"]) for r in self.db.execute("SELECT key,value FROM state ORDER BY key")}

    def events(self, include_hidden: bool = False) -> list[dict[str, Any]]:
        arr = []
        for r in self.db.execute("SELECT * FROM events ORDER BY seq"):
            d = json.loads(r["data"])
            if include_hidden or d["visibility"] != "GM_HIDDEN":
                arr.append({"seq": r["seq"], "id": r["id"], "kind": r["kind"],
                            "actor": r["actor"], "data": d, "hash": r["hash"]})
        return arr

    def append_event(self, *, kind: str, actor: str, description: str,
        declaration_id: str | None = None, causal_refs: list[str] | None = None,
        source_rule: str | None = None, state_delta: list[dict] | None = None,
        visibility: str = "PLAYER_PUBLIC", knowledge_used: list[str] | None = None,
        knowledge_granted: list[dict] | None = None, correction_of: str | None = None,
        canon_change: bool = False, event_id: str | None = None) -> str:
        """Transactional event + materialized state; rollback on any failed validation."""
        causal_refs = causal_refs or []
        state_delta = state_delta or []
        knowledge_used = knowledge_used or []
        knowledge_granted = knowledge_granted or []
        if kind not in EVENT_KINDS or not description.strip() or not actor.strip():
            raise GuardrailError("invalid event kind/actor/description")
        if visibility not in {"PLAYER_PUBLIC", "PC_KNOWN", "GM_HIDDEN", "SYSTEM_AUDIT"}:
            raise GuardrailError("invalid visibility")
        if canon_change:
            raise GuardrailError("scenario canon is read-only")
        event_id = event_id or _ident("EVT")
        with self._transaction():
            if self._has_event(event_id):
                raise GuardrailError("event ID already committed; do not replay")
            for ref in causal_refs:
                if not self._has_event(ref):
                    raise GuardrailError("causal event not confirmed: " + ref)
            if kind in PLAYER_KINDS:
                if actor != "pc":
                    raise GuardrailError("player declaration must have actor pc")
                decl = self._get_declaration(declaration_id, PLAYER_KINDS[kind])
                if description != decl["text"]:
                    raise GuardrailError("action differs from the player's literal declaration")
                if self.db.execute("SELECT 1 FROM events WHERE json_extract(data,'$.declaration_id')=?", (declaration_id,)).fetchone():
                    raise GuardrailError("declaration was already consumed")
            elif kind in ("correction", "character_import"):
                approval = self._get_declaration(declaration_id, "choice")
                if kind == "correction":
                    correction_fingerprint=hashlib.sha256(_json({"target":correction_of,"description":description,"delta":state_delta}).encode()).hexdigest()
                    if not correction_of or not self._has_event(correction_of) or correction_of not in approval["text"] or correction_fingerprint not in approval["text"]:
                        raise GuardrailError("correction requires signed approval naming target and exact correction hash")
                if kind == "character_import":
                    import_fingerprint=hashlib.sha256(_json(state_delta).encode()).hexdigest()
                    if "IMPORT_CHARACTER" not in approval["text"] or import_fingerprint not in approval["text"]:
                        raise GuardrailError("character import requires signed approval for exact sheet delta hash")
            elif actor == "pc":
                raise GuardrailError("non-player event cannot assign voluntary PC agency")
            if kind in NON_FACT_KINDS and (state_delta or knowledge_granted):
                raise GuardrailError("NPC claim/GM plan is not an accomplished fact")
            if kind == "npc_action":
                for fact in knowledge_used:
                    if not self.db.execute("SELECT 1 FROM knowledge WHERE actor=? AND fact=?", (actor, fact)).fetchone():
                        raise GuardrailError("NPC lacks registered knowledge: " + fact)
            if kind == "world_event":
                if not causal_refs:
                    raise GuardrailError("world event requires a confirmed causal anchor")
                valid_factual_anchor = self.db.execute(
                    "SELECT 1 FROM events WHERE id IN (%s) AND kind NOT IN ('gm_plan','npc_claim') LIMIT 1" % ",".join("?" for _ in causal_refs), causal_refs).fetchone()
                if not valid_factual_anchor:
                    raise GuardrailError("NPC claim or GM plan alone cannot establish a world event")
            if kind == "character_import" and self.db.execute("SELECT 1 FROM state WHERE key LIKE 'pc.%' LIMIT 1").fetchone():
                raise GuardrailError("character already imported")
            for delta in state_delta:
                if set(delta) != {"key", "before", "after", "reason"} or not delta["reason"]:
                    raise GuardrailError("state delta must include exact before/after and reason")
                key = delta["key"]
                row = self.db.execute("SELECT value FROM state WHERE key=?", (key,)).fetchone()
                old = json.loads(row[0]) if row else None
                if old != delta["before"]:
                    raise GuardrailError("stale or fabricated prior state for " + key)
                if key.startswith("canon."):
                    raise GuardrailError("canon state cannot be changed")
                if kind not in PLAYER_KINDS and kind != "character_import" and key in FORBIDDEN_WORLD_FIELDS:
                    forced_move=(key=="pc.location" and delta["reason"].startswith("involuntary:") and source_rule and causal_refs and
                        self.db.execute("SELECT 1 FROM events WHERE id IN (%s) AND kind IN ('npc_action','world_event') LIMIT 1" % ",".join("?" for _ in causal_refs), causal_refs).fetchone())
                    if not forced_move:
                        raise GuardrailError("world cannot silently decide PC actions/position")
                if key in OPTIONAL_FIELDS and isinstance(old, (float,int)) and isinstance(delta["after"], (float,int)) and delta["after"] < old:
                    if delta["reason"].startswith("optional:"):
                        self._get_declaration(declaration_id, "choice")
                    elif not (delta["reason"].startswith("involuntary:") and causal_refs and source_rule):
                        raise GuardrailError("resource reduction requires signed choice or sourced involuntary effect")
                if key.startswith("pc.") and kind in ("npc_claim", "gm_plan"):
                    raise GuardrailError("claim/plan cannot affect character sheet")
                if key.startswith("pc.") and kind not in PLAYER_KINDS and kind not in {"character_import", "correction"} and not causal_refs:
                    raise GuardrailError("involuntary PC change requires causal event")
            for grant in knowledge_granted:
                if set(grant) != {"actor", "fact"} or kind in NON_FACT_KINDS:
                    raise GuardrailError("knowledge grant must be traceable to accomplished event")
            data = {"description": description, "declaration_id": declaration_id, "causal_refs": causal_refs,
                    "state_delta": state_delta, "source_rule": source_rule, "visibility": visibility,
                    "knowledge_used": knowledge_used, "knowledge_granted": knowledge_granted,
                    "correction_of": correction_of, "engine_version": VERSION}
            self._insert_event(event_id, kind, actor, data)
            for d in state_delta:
                self.db.execute("INSERT INTO state(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                    (d["key"], _json(d["after"])))
            for grant in knowledge_granted:
                self.db.execute("INSERT OR IGNORE INTO knowledge VALUES(?,?,?)", (grant["actor"], grant["fact"], event_id))
        return event_id

    def _insert_event(self, id: str, kind: str, actor: str, data: dict) -> None:
        prev = self.db.execute("SELECT hash FROM events ORDER BY seq DESC LIMIT 1").fetchone()
        prev_hash = prev[0] if prev else GENESIS
        timestamp = _now()
        message = {"id": id, "kind": kind, "actor": actor, "data": data, "timestamp": timestamp, "prev_hash": prev_hash}
        digest = hashlib.sha256(_json(message).encode()).hexdigest()
        self.db.execute("INSERT INTO events(id,kind,actor,data,timestamp,prev_hash,hash) VALUES(?,?,?,?,?,?,?)",
                        (id, kind, actor, _json(data), timestamp, prev_hash, digest))

    def prepare_roll(self, *, pool: int, hunger: int, difficulty: int, label: str,
                     actor: str, rule_source: str, causal_refs: list[str] | None = None,
                     test_type: str = "pool") -> str:
        if test_type not in {"pool", "rouse"}:
            raise GuardrailError("unsupported test type")
        if test_type == "rouse" and (pool != 1 or hunger != 0 or difficulty != 1 or actor != "pc"):
            raise GuardrailError("Rouse check must be 1d10, 0 Hunger dice, difficulty 1, PC actor")
        if type(pool) is not int or type(hunger) is not int or pool < 1 or pool > 30 or hunger < 0 or hunger > min(pool,5):
            raise GuardrailError("invalid V5 dice pool")
        if type(difficulty) is not int or not 0 <= difficulty <= 10:
            raise GuardrailError("invalid difficulty")
        if not label.strip() or not actor.strip() or not rule_source.strip():
            raise GuardrailError("roll label, actor and rule source required")
        refs = causal_refs or []
        for ref in refs:
            if not self._has_event(ref):
                raise GuardrailError("roll causal event not confirmed")
        if actor == "pc":
            char=self.db.execute("SELECT value FROM state WHERE key='pc.hunger'").fetchone()
            if not char:
                raise GuardrailError("PC sheet not imported; cannot roll")
            if test_type == "pool" and json.loads(char[0]) != hunger:
                raise GuardrailError("declared Hunger differs from persisted PC sheet")
            if not refs:
                raise GuardrailError("PC roll must be anchored to a confirmed declaration event")
            anchor = self.db.execute("SELECT kind FROM events WHERE id=?", (refs[-1],)).fetchone()
            if not anchor or anchor["kind"] not in {"player_action", "player_attempt"}:
                raise GuardrailError("PC roll requires an action or attempt anchor")
        id = _ident("PREP")
        spec = {"pool":pool,"hunger":hunger,"difficulty":difficulty,"label":label,
                "actor":actor,"rule_source":rule_source,"causal_refs":refs,"prepared_at":_now(),"test_type":test_type}
        with self._transaction():
            self.db.execute("INSERT INTO roll_preps(id,spec,status) VALUES(?,?,'PREPARED')", (id,_json(spec)))
        return id

    def execute_roll(self, prep_id: str, *, _rng=None) -> dict[str, Any]:
        """One execution per prepared roll. _rng is exclusively for deterministic tests."""
        with self._transaction():
            r=self.db.execute("SELECT spec,status,event_id FROM roll_preps WHERE id=?",(prep_id,)).fetchone()
            if not r: raise GuardrailError("roll preparation absent")
            if r["status"] == "EXECUTED":
                saved=self.db.execute("SELECT id,raw,outcome,event_id FROM rolls WHERE event_id=?",(r["event_id"],)).fetchone()
                return {"roll_id":saved["id"],"event_id":saved["event_id"],"raw":json.loads(saved["raw"]),
                        "outcome":json.loads(saved["outcome"]),"idempotent":True}
            if r["status"] != "PREPARED": raise GuardrailError("roll not executable")
            spec=json.loads(r["spec"])
            rng = _rng if _rng is not None else secrets.SystemRandom()
            normal=[rng.randint(1,10) for _ in range(spec["pool"]-spec["hunger"])]
            hunger=[rng.randint(1,10) for _ in range(spec["hunger"])]
            outcome=score_v5(normal,hunger,spec["difficulty"])
            state_delta=[]
            if spec.get("test_type") == "rouse":
                hrow=self.db.execute("SELECT value FROM state WHERE key='pc.hunger'").fetchone()
                if not hrow: raise GuardrailError("PC Hunger undefined; import approved character first")
                old=json.loads(hrow[0])
                if type(old) is not int or not 0 <= old <= 5: raise GuardrailError("invalid stored Hunger")
                # Rouse's success is determined by its single d10 being 6+, not by pool critical rules.
                rouse_success = normal[0] >= 6
                updated = min(5,old+(0 if rouse_success else 1))
                outcome={"rouse_success":rouse_success,"hunger_before":old,"hunger_after":updated,
                         "hunger_max_warning":not rouse_success and old==5}
                if updated!=old:
                    state_delta=[{"key":"pc.hunger","before":old,"after":updated,"reason":"involuntary:rouse_failed"}]
            id,roll_id=_ident("EVT"),_ident("ROLL")
            raw={"normal":normal,"hunger":hunger,"spec":spec,"engine_version":VERSION}
            data={"description":spec["label"],"declaration_id":None,"causal_refs":spec["causal_refs"],
                  "state_delta":state_delta,"source_rule":spec["rule_source"],"visibility":"SYSTEM_AUDIT",
                  "knowledge_used":[],"knowledge_granted":[],"correction_of":None,
                  "roll_id":roll_id,"raw_sha256":hashlib.sha256(_json(raw).encode()).hexdigest(),"result":outcome,"engine_version":VERSION}
            self._insert_event(id,"mechanical_result",spec["actor"],data)
            self.db.execute("INSERT INTO rolls VALUES(?,?,?,?,?)",(roll_id,id,prep_id,_json(raw),_json(outcome)))
            for d in state_delta:
                self.db.execute("INSERT INTO state(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                    (d["key"],_json(d["after"])))
            self.db.execute("UPDATE roll_preps SET status='EXECUTED',event_id=? WHERE id=?",(id,prep_id))
        return {"roll_id":roll_id,"event_id":id,"raw":raw,"outcome":outcome,"idempotent":False}

    def reroll_willpower(self, roll_id: str, indices: list[int], choice_declaration_id: str, *, _rng=None) -> dict[str,Any]:
        """V5: player-approved 1 WP for reroll of up to 3 NON-Hunger dice (once)."""
        with self._transaction():
            approval=self._get_declaration(choice_declaration_id,"choice")
            if (roll_id not in approval["text"] or "REROLL" not in approval["text"] or
                "indices="+",".join(map(str,indices)) not in approval["text"]):
                raise GuardrailError("signed explicit reroll consent naming roll ID and indices required")
            if self.db.execute("SELECT 1 FROM events WHERE json_extract(data,'$.declaration_id')=?",(choice_declaration_id,)).fetchone():
                raise GuardrailError("player choice was already consumed")
            if self.db.execute("SELECT 1 FROM events WHERE json_extract(data,'$.rerolls_roll_id')=?",(roll_id,)).fetchone():
                raise GuardrailError("roll has already been rerolled")
            roll=self.db.execute("SELECT raw FROM rolls WHERE id=?",(roll_id,)).fetchone()
            if not roll: raise GuardrailError("unknown roll")
            base=json.loads(roll["raw"]); spec=base["spec"]
            if spec["actor"]!="pc" or spec.get("test_type") != "pool":
                raise GuardrailError("reroll only supported for PC normal pool tests")
            normal=list(base["normal"]); hunger=base["hunger"]
            if (not indices or len(indices)>3 or len(set(indices))!=len(indices) or
                any(type(i) is not int or i<0 or i>=len(normal) for i in indices)):
                raise GuardrailError("choose 1–3 unique indices of non-Hunger dice")
            resource=self.db.execute("SELECT value FROM state WHERE key='pc.willpower.current'").fetchone()
            if not resource or type(json.loads(resource[0])) is not int or json.loads(resource[0]) <= 0:
                raise GuardrailError("no available Willpower in imported character")
            old=json.loads(resource[0]);new=old-1
            rng=_rng if _rng is not None else secrets.SystemRandom()
            before={str(i):normal[i] for i in indices}
            for i in indices: normal[i]=rng.randint(1,10)
            outcome=score_v5(normal,hunger,spec["difficulty"])
            new_roll_id,event_id,prep_id=_ident("ROLL"),_ident("EVT"),_ident("PREP")
            raw={"normal":normal,"hunger":hunger,"spec":spec,"reroll_of":roll_id,
                 "replaced":before,"indices":indices,"engine_version":VERSION}
            delta=[{"key":"pc.willpower.current","before":old,"after":new,"reason":"optional:willpower_reroll"}]
            data={"description":"Player-approved Willpower reroll", "declaration_id":choice_declaration_id,
                  "causal_refs":[spec["causal_refs"][-1]],"state_delta":delta,"source_rule":spec["rule_source"],
                  "visibility":"SYSTEM_AUDIT","knowledge_used":[],"knowledge_granted":[],"correction_of":None,
                  "rerolls_roll_id":roll_id,"roll_id":new_roll_id,"raw_sha256":hashlib.sha256(_json(raw).encode()).hexdigest(),
                  "result":outcome,"engine_version":VERSION}
            self._insert_event(event_id,"mechanical_result","pc",data)
            self.db.execute("INSERT INTO roll_preps VALUES(?,?,'EXECUTED',?)",(prep_id,_json(spec),event_id))
            self.db.execute("INSERT INTO rolls VALUES(?,?,?,?,?)",(new_roll_id,event_id,prep_id,_json(raw),_json(outcome)))
            self.db.execute("UPDATE state SET value=? WHERE key='pc.willpower.current'",(_json(new),))
        return {"roll_id":new_roll_id,"event_id":event_id,"reroll_of":roll_id,"raw":raw,"outcome":outcome}

    def verify_integrity(self) -> dict[str,Any]:
        errors=[];last=GENESIS
        for row in self.db.execute("SELECT * FROM events ORDER BY seq"):
            if row["prev_hash"]!=last: errors.append("broken linkage at " + row["id"])
            body={"id":row["id"],"kind":row["kind"],"actor":row["actor"],
                  "data":json.loads(row["data"]),"timestamp":row["timestamp"],"prev_hash":row["prev_hash"]}
            digest=hashlib.sha256(_json(body).encode()).hexdigest()
            if digest!=row["hash"]: errors.append("modified event " + row["id"])
            last=row["hash"]
        for row in self.db.execute("SELECT id,payload,signature FROM declarations"):
            try:
                self._verify_token({"payload":json.loads(row["payload"]),"signature":row["signature"]})
            except GuardrailError:
                errors.append("invalid saved player signature: " + row["id"])
        for row in self.db.execute("SELECT * FROM rolls"):
            raw=json.loads(row["raw"])
            if raw["spec"].get("test_type") == "rouse":
                expected=json.loads(row["outcome"])
                if expected.get("rouse_success") != (raw["normal"][0]>=6):
                    errors.append("rouse score changed: "+row["id"])
                if expected.get("hunger_after") != min(5,expected.get("hunger_before",-1)+(0 if expected.get("rouse_success") else 1)):
                    errors.append("rouse hunger changed: "+row["id"])
            else:
                expected=score_v5(raw["normal"],raw["hunger"],raw["spec"]["difficulty"])
            if expected!=json.loads(row["outcome"]):errors.append("roll score changed: "+row["id"])
            event=self.db.execute("SELECT data FROM events WHERE id=?",(row["event_id"],)).fetchone()
            if not event:errors.append("orphan roll: "+row["id"])
            elif json.loads(event["data"]).get("raw_sha256") != hashlib.sha256(_json(raw).encode()).hexdigest():
                errors.append("roll raw changed: "+row["id"])
        projected={}
        for row in self.db.execute("SELECT data FROM events ORDER BY seq"):
            for change in json.loads(row["data"]).get("state_delta", []):
                if projected.get(change["key"]) != change["before"]:
                    errors.append("invalid projected prior state: " + change["key"])
                projected[change["key"]]=change["after"]
        if projected != self.state():
            errors.append("materialized state differs from ledger")
        return {"ok":not errors,"errors":errors,"events":self.db.execute("SELECT count(*) FROM events").fetchone()[0],
                "rolls":self.db.execute("SELECT count(*) FROM rolls").fetchone()[0],"last_hash":last}

    def checkpoint(self) -> dict[str,Any]:
        row=self.db.execute("SELECT id,seq FROM events ORDER BY seq DESC LIMIT 1").fetchone()
        return {"phase":self.db.execute("SELECT value FROM meta WHERE key='phase'").fetchone()[0],
                "last_event_id":row["id"] if row else None,"last_event_seq":row["seq"] if row else 0,
                "character_present": self.db.execute("SELECT 1 FROM state WHERE key LIKE 'pc.%' LIMIT 1").fetchone() is not None,
                "state":self.state(), "integrity":self.verify_integrity()}
