#!/usr/bin/env python3
"""Novydres core command line (CLI). Use Python 3.11+ and pip install cryptography."""
import argparse
import json
import hashlib
import sqlite3
from pathlib import Path
import sys
from novydres_core import Chronicle, GuardrailError, create_player_key, sign_declaration


def parse():
    p=argparse.ArgumentParser(description="Novydres Chronicle Core v0.1 — local trusted event store")
    p.add_argument("--db",default="data/chronicle.sqlite3",help="Persistent SQLite path")
    cmds=p.add_subparsers(dest="cmd",required=True)
    a=cmds.add_parser("keygen",help="Player ONLY: creates private + public key")
    a.add_argument("--private",required=True);a.add_argument("--public",required=True)
    a=cmds.add_parser("register-player",help="Register player's public key; irreversible by CLI")
    a.add_argument("--public",required=True)
    a=cmds.add_parser("sign",help="Player ONLY: sign an EXACT declaration")
    a.add_argument("--private",required=True);a.add_argument("--kind",required=True,choices=["action","attempt","speech","choice","question"])
    a.add_argument("--text",required=True);a.add_argument("--output",required=True)
    a=cmds.add_parser("accept",help="Validate signed player message before use")
    a.add_argument("token_file")
    a=cmds.add_parser("event",help="Validate and commit JSON event candidate")
    a.add_argument("candidate_file")
    a=cmds.add_parser("prepare-roll",help="Store immutable roll parameters before execution")
    a.add_argument("spec_file")
    a=cmds.add_parser("roll",help="Execute prepared roll exactly once (idempotent)")
    a.add_argument("prep_id")
    a=cmds.add_parser("reroll",help="Player-approved Willpower reroll of non-Hunger dice")
    a.add_argument("roll_id");a.add_argument("--indices",required=True,help="0-based comma-separated non-Hunger die indices")
    a.add_argument("--choice",required=True,help="Accepted signed player choice declaration ID")
    a=cmds.add_parser("fingerprint",help="SHA-256 for a pending import/correction candidate")
    a.add_argument("candidate_file")
    a=cmds.add_parser("backup",help="SQLite consistent physical backup; upload separately to Drive")
    a.add_argument("--out",required=True)
    a=cmds.add_parser("export",help="Export read-only checkpoint and player-safe ledger")
    a.add_argument("--out",required=True)
    a=cmds.add_parser("events",help="List all public committed events")
    a=cmds.add_parser("checkpoint",help="Return current state and ledger tip")
    a=cmds.add_parser("audit",help="Validate hash chain, roll results, state projection")
    return p.parse_args()


def main():
    a=parse()
    try:
        if a.cmd=="keygen":
            create_player_key(a.private,a.public)
            out={"created":True,"private_file":a.private,"public_file":a.public,"warning":"Keep private key off the Drive and inaccessible to Narrator!"}
        elif a.cmd=="sign":
            token=sign_declaration(a.private,a.kind,a.text)
            Path(a.output).write_text(json.dumps(token,ensure_ascii=False,indent=2),encoding="utf-8")
            out={"signed":True,"token_file":a.output,"declaration_id":token["payload"]["id"]}
        else:
            store=Chronicle(a.db)
            try:
                if a.cmd=="register-player": out=store.register_player(Path(a.public).read_bytes().hex()) or {"registered":True}
                elif a.cmd=="accept": out={"declaration_id":store.accept_declaration(json.loads(Path(a.token_file).read_text(encoding="utf-8")))}
                elif a.cmd=="event": out={"event_id":store.append_event(**json.loads(Path(a.candidate_file).read_text(encoding="utf-8")))}
                elif a.cmd=="prepare-roll": out={"prep_id":store.prepare_roll(**json.loads(Path(a.spec_file).read_text(encoding="utf-8")))}
                elif a.cmd=="roll": out=store.execute_roll(a.prep_id)
                elif a.cmd=="reroll": out=store.reroll_willpower(a.roll_id,[int(x) for x in a.indices.split(",")],a.choice)
                elif a.cmd=="fingerprint":
                    e=json.loads(Path(a.candidate_file).read_text(encoding="utf-8"))
                    if e["kind"]=="character_import": value=e.get("state_delta",[])
                    elif e["kind"]=="correction": value={"target":e["correction_of"],"description":e["description"],"delta":e.get("state_delta",[])}
                    else: raise GuardrailError("fingerprint for character_import or correction only")
                    raw=json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(",",":"),allow_nan=False)
                    out={"sha256":hashlib.sha256(raw.encode()).hexdigest(),"kind":e["kind"]}
                elif a.cmd=="backup":
                    outpath=Path(a.out)
                    if outpath.exists(): raise GuardrailError("backup destination already exists")
                    outpath.parent.mkdir(parents=True,exist_ok=True)
                    with sqlite3.connect(str(outpath)) as target: store.db.backup(target)
                    out={"backup":str(outpath),"sha256":hashlib.sha256(outpath.read_bytes()).hexdigest()}
                elif a.cmd=="export":
                    outpath=Path(a.out)
                    if outpath.exists(): raise GuardrailError("export destination already exists")
                    outpath.parent.mkdir(parents=True,exist_ok=True)
                    artifact={"checkpoint":store.checkpoint(),"events":store.events(include_hidden=False)}
                    outpath.write_text(json.dumps(artifact,ensure_ascii=False,indent=2),encoding="utf-8")
                    out={"export":str(outpath),"sha256":hashlib.sha256(outpath.read_bytes()).hexdigest(),"warning":"Player-safe export only; never interpret it as full narrator-state backup"}
                elif a.cmd=="events": out=store.events()
                elif a.cmd=="checkpoint": out=store.checkpoint()
                elif a.cmd=="audit": out=store.verify_integrity()
            finally:
                store.close()
        print(json.dumps(out,ensure_ascii=False,indent=2))
    except (GuardrailError,FileNotFoundError,ValueError,KeyError) as err:
        print(json.dumps({"ok":False,"error":str(err)},ensure_ascii=False),file=sys.stderr)
        sys.exit(2)

if __name__ == "__main__": main()
